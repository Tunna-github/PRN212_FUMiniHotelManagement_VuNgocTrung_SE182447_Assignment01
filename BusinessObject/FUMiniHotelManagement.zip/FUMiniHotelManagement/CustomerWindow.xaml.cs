﻿using BusinessObject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FUMiniHotelManagement
{
    /// <summary>
    /// Interaction logic for CustomerWindow.xaml
    /// </summary>
    public partial class CustomerWindow : Window
    {
        private Customer loggedInCustomer;
        public CustomerWindow(Customer customer)
        {
            InitializeComponent();
            this.loggedInCustomer = customer;

            DataContext = new
            {
                CustomerGreeting = $"Hello, {loggedInCustomer.CustomerFullName}!",
                CustomerFullName = loggedInCustomer.CustomerFullName,
                EmailAddress = loggedInCustomer.EmailAddress,
                Telephone = loggedInCustomer.Telephone,
                CustomerBirthday = loggedInCustomer.CustomerBirthday.ToString("MM/dd/yyyy")
            };
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            CustomerDialog customerDialog = new CustomerDialog(loggedInCustomer);
            bool? result = customerDialog.ShowDialog();

            if (result == true)
            {
                // Update the displayed customer info after profile is updated
                DataContext = new
                {
                    CustomerGreeting = $"Hello, {loggedInCustomer.CustomerFullName}!",
                    CustomerFullName = loggedInCustomer.CustomerFullName,
                    EmailAddress = loggedInCustomer.EmailAddress,
                    Telephone = loggedInCustomer.Telephone,
                    CustomerBirthday = loggedInCustomer.CustomerBirthday.ToString("MM/dd/yyyy")
                };
            }
        }
    }
}
