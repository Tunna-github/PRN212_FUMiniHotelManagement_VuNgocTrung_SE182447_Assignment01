﻿using BusinessObject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FUMiniHotelManagement
{
    /// <summary>
    /// Interaction logic for CustomerDialog.xaml
    /// </summary>
    public partial class CustomerDialog : Window
    {
        public Customer Customer { get; private set; }
        public CustomerDialog(Customer customer)
        {
            InitializeComponent();
            Customer = customer ?? new Customer();
            FullNametxt.Text = Customer.CustomerFullName;
            EmailBox.Text = Customer.EmailAddress;
            Telephonetxt.Text = Customer.Telephone;
            BirthdayPicker.SelectedDate = Customer.CustomerBirthday.ToDateTime(new TimeOnly());
            PasswordBox.Password = Customer.Password; 
            StatusComboBox.SelectedItem = Customer.CustomerStatus == 1 ? StatusComboBox.Items[0] : StatusComboBox.Items[1];
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FullNametxt.Text) || string.IsNullOrWhiteSpace(EmailBox.Text) || string.IsNullOrEmpty(PasswordBox.Password))
            {
                MessageBox.Show("Full Name and Email and Password are required.");
                return;
            }

            Customer.CustomerFullName = FullNametxt.Text;
            Customer.EmailAddress = EmailBox.Text;
            Customer.Telephone = Telephonetxt.Text;
            Customer.CustomerBirthday = BirthdayPicker.SelectedDate.HasValue ? DateOnly.FromDateTime(BirthdayPicker.SelectedDate.Value) : DateOnly.MinValue;
            Customer.Password = PasswordBox.Password;
            Customer.CustomerStatus = (StatusComboBox.SelectedIndex == 0) ? (byte)1 : (byte)2;

            DialogResult = true; 
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DialogResult = false; 
            Close();
        }
    }
}
