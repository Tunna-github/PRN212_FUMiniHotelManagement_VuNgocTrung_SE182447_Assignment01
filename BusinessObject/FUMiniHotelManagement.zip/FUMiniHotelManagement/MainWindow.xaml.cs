﻿using Microsoft.Extensions.Configuration;
using MiniHotelService;
using System.Configuration;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FUMiniHotelManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ICustomerService customerService;
        private readonly IConfiguration configuration;

        public MainWindow()
        {
            InitializeComponent();
            customerService = new CustomerService();

            // Load configuration
            configuration = ((App)Application.Current).Configuration;

        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Email or password cannot be empty.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string adminEmail = configuration["AdminAccount:Email"];
            string adminPassword = configuration["AdminAccount:Password"];

            if (email == adminEmail && password == adminPassword)
            {
                AdminWindow adminWindow = new AdminWindow();
                adminWindow.Show();
                this.Close();
                return;
            }

            var customers = customerService.GetCustomers();
            if (customers == null)
            {
                StatusTextBlock.Text = "Error retrieving customer data. Please try again later.";
                return;
            }

            var customer = customers.FirstOrDefault(c => c.EmailAddress == email && c.Password == password);
            if (customer != null)
            {
                if (customer.CustomerStatus == 2)
                {
                    MessageBox.Show("You have been ban");

                }
                else
                {
                    MessageBox.Show($"Logged in as Customer: {customer.CustomerFullName}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    CustomerWindow customerWindow = new CustomerWindow(customer);
                    customerWindow.Show();
                    this.Close();
                    return;
                }
            }
            else
            {
                StatusTextBlock.Text = "Invalid email or password. Please try again.";
            }
        }

        private void CacncelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void EmailTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var emailTextBox = sender as TextBox;
            string emailText = emailTextBox?.Text;

            // Optionally perform validation or other logic
            if (!string.IsNullOrWhiteSpace(emailText))
            {
                Console.WriteLine("Email text changed: " + emailText);
            }
        }
    }
}