﻿using BusinessObject.Models;
using MiniHotelService;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FUMiniHotelManagement
{
    /// <summary>
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window, INotifyPropertyChanged
    {
        private readonly ICustomerService customerService;
        private readonly IRoomInfoService roomService;
        private ObservableCollection<Customer> customers;
        private ObservableCollection<RoomInformation> rooms;
        private Customer selectedCustomer;
        private RoomInformation selectedRoom;
        private string customerSearchText;
        private string roomSearchText;

        public event PropertyChangedEventHandler? PropertyChanged;

        public AdminWindow()
        {
            InitializeComponent();
            customerService = new CustomerService();
            roomService = new RoomInfoService();
            LoadCustomers();
            LoadRooms();
            DataContext = this;
        }

        private void LoadCustomers()
        {
            Customers = new ObservableCollection<Customer>(customerService.GetCustomers());
        }

        private void LoadRooms()
        {
            Rooms = new ObservableCollection<RoomInformation>(roomService.GetRoomInformations());
        }

        public ObservableCollection<Customer> Customers
        {
            get => customers;
            set
            {
                customers = value;
                OnPropertyChanged(nameof(Customers));
                OnPropertyChanged(nameof(FilteredCustomers));
            }
        }

        public ObservableCollection<RoomInformation> Rooms
        {
            get => rooms;
            set
            {
                rooms = value;
                OnPropertyChanged(nameof(Rooms));
                OnPropertyChanged(nameof(FilteredRooms));
            }
        }

        public Customer SelectedCustomer
        {
            get => selectedCustomer;
            set
            {
                selectedCustomer = value;
                OnPropertyChanged(nameof(SelectedCustomer));
            }
        }

        public RoomInformation SelectedRoom
        {
            get => selectedRoom;
            set
            {
                selectedRoom = value;
                OnPropertyChanged(nameof(SelectedRoom));
            }
        }

        public string CustomerSearchText
        {
            get => customerSearchText;
            set
            {
                customerSearchText = value;
                OnPropertyChanged(nameof(CustomerSearchText));
                OnPropertyChanged(nameof(FilteredCustomers));
            }
        }

        public string RoomSearchText
        {
            get => roomSearchText;
            set
            {
                roomSearchText = value;
                OnPropertyChanged(nameof(RoomSearchText));
                OnPropertyChanged(nameof(FilteredRooms));
            }
        }

        public IEnumerable<Customer> FilteredCustomers =>
            string.IsNullOrWhiteSpace(CustomerSearchText)
                ? Customers
                : Customers.Where(c => c.CustomerFullName.Contains(CustomerSearchText, StringComparison.OrdinalIgnoreCase));

        public IEnumerable<RoomInformation> FilteredRooms =>
            string.IsNullOrWhiteSpace(RoomSearchText)
                ? Rooms
                : Rooms.Where(r => r.RoomNumber.Contains(RoomSearchText, StringComparison.OrdinalIgnoreCase));

        // Customer management methods
        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            var newCustomer = new Customer();
            var customerDialog = new CustomerDialog(newCustomer);
            if (customerDialog.ShowDialog() == true)
            {
                customerService.AddCustomer(newCustomer);
                Customers.Add(newCustomer);
                OnPropertyChanged(nameof(FilteredCustomers));
            }
        }

        private void EditCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedCustomer == null) return;
            var customerDialog = new CustomerDialog(SelectedCustomer);
            if (customerDialog.ShowDialog() == true)
            {
                customerService.UpdateCustomer(SelectedCustomer);
                RefreshCustomers();
            }
        }

        private void DeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedCustomer == null) return;
            var result = MessageBox.Show($"Are you sure you want to delete {SelectedCustomer.CustomerFullName}?",
                "Delete Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                customerService.DeleteCustomer(SelectedCustomer.CustomerId);
                Customers.Remove(SelectedCustomer);
                OnPropertyChanged(nameof(FilteredCustomers));
            }
        }

        // Room management methods
        private void AddRoom_Click(object sender, RoutedEventArgs e)
        {
            var newRoom = new RoomInformation();
            var roomDialog = new RoomInformationDialog(newRoom);
            if (roomDialog.ShowDialog() == true)
            {
                roomService.AddRoomInformation(newRoom);
                RefreshRooms();
            }
        }

        private void EditRoom_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedRoom == null) return;
            var roomDialog = new RoomInformationDialog(SelectedRoom);
            if (roomDialog.ShowDialog() == true)
            {
                roomService.UpdateRoomInformation(SelectedRoom);
                RefreshRooms();
            }
        }

        private void DeleteRoom_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedRoom == null) return;
            var result = MessageBox.Show($"Are you sure you want to delete room {SelectedRoom.RoomNumber}?",
                "Delete Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                roomService.DeleteRoomInformation(SelectedRoom.RoomId);
                RefreshRooms();
            }
        }

        private void RefreshCustomers()
        {
            var updatedCustomers = customerService.GetCustomers();
            Customers.Clear();
            foreach (var customer in updatedCustomers)
            {
                Customers.Add(customer);
            }
            OnPropertyChanged(nameof(FilteredCustomers));
        }

        private void RefreshRooms()
        {
            var updatedRooms = roomService.GetRoomInformations();
            Rooms.Clear();
            foreach (var room in updatedRooms)
            {
                Rooms.Add(room);
            }
            OnPropertyChanged(nameof(FilteredRooms));
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
