﻿using BusinessObject.Models;
using MiniHotelService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FUMiniHotelManagement
{
    /// <summary>
    /// Interaction logic for RoomInformationDialog.xaml
    /// </summary>
    public partial class RoomInformationDialog : Window
    {
        public RoomInformation Room { get; private set; }
        private readonly IRoomTypeService iroomTypeService;
        public RoomInformationDialog(RoomInformation room)
        {
            InitializeComponent();
            Room = room ?? new RoomInformation();
            iroomTypeService = new RoomTypeService(); // Initialize the room type service
            LoadRoomTypes(); // Load room types into ComboBox

            // Populate fields if editing an existing room
            RoomNumberTextBox.Text = Room.RoomNumber;
            DescriptionTextBox.Text = Room.RoomDetailDescription;
            MaxCapacityTextBox.Text = Room.RoomMaxCapacity.ToString();
            PriceTextBox.Text = Room.RoomPricePerDay.ToString("F2");
            StatusComboBox.SelectedItem = Room.RoomStatus == 1 ? StatusComboBox.Items[0] : StatusComboBox.Items[1];

            // Set the selected room type in the ComboBox
            foreach (ComboBoxItem item in RoomTypeComboBox.Items)
            {
                if ((int)item.Tag == Room.RoomTypeId)
                {
                    RoomTypeComboBox.SelectedItem = item;
                    break;
                }
            }
        }

        private void LoadRoomTypes()
        {
            var roomTypes = iroomTypeService.GetRoomTypes(); 
            foreach (var type in roomTypes)
            {
                RoomTypeComboBox.Items.Add(new ComboBoxItem { Content = type.RoomTypeName, Tag = type.RoomTypeId });
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(RoomNumberTextBox.Text) || string.IsNullOrWhiteSpace(DescriptionTextBox.Text) ||
                !int.TryParse(MaxCapacityTextBox.Text, out int maxCapacity) || !decimal.TryParse(PriceTextBox.Text, out decimal price) ||
                RoomTypeComboBox.SelectedItem == null)
            {
                MessageBox.Show("All fields must be filled correctly.");
                return;
            }

            Room.RoomNumber = RoomNumberTextBox.Text;
            Room.RoomDetailDescription = DescriptionTextBox.Text;
            Room.RoomMaxCapacity = maxCapacity;
            Room.RoomPricePerDay = price;
            Room.RoomStatus = (StatusComboBox.SelectedItem as ComboBoxItem).Content.ToString().StartsWith("1") ? 1 : 2;
            Room.RoomTypeId = (int)((ComboBoxItem)RoomTypeComboBox.SelectedItem).Tag;
            Console.WriteLine($"RoomTypeID to be saved: {Room.RoomTypeId}"); 

            DialogResult = true; 
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
